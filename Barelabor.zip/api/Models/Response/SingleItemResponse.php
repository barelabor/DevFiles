<?php 
class SingleItemResponse {
	var $status;
	var $item;
}
?>