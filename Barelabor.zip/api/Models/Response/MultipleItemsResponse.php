<?php 
class MultipleItemsResponse {
	var $status;
	var $items;
}
?>