<?php 
class BooleanResponse {
	var $status;
}
?>