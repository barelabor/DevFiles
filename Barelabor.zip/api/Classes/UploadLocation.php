<?php
class UploadLocation
{
  const AVATAR = '/Uploads/Users/Avatars/';
}
?>