//
//  ButtonsCollectionViewCell.swift
//  BareLabor
//
//  Dustin Allen
//  Copyright © 2016 BareLabor. All rights reserved.
//

import UIKit

class ButtonsCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var title : UILabel!
}
