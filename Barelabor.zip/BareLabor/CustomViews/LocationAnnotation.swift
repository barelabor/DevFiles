//
//  LocationAnnotation.swift
//  BareLabor
//
//  Dustin Allen
//  Copyright © 2016 BareLabor. All rights reserved.
//

import UIKit
import MapKit

class LocationAnnotation: MKAnnotationView {
    
}
